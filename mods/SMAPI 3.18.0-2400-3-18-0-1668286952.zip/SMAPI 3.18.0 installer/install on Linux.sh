#!/bin/bash

cd "`dirname "$0"`"
internal/linux/SMAPI.Installer
